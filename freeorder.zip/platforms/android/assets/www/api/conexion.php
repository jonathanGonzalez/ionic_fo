<?php
$db = new PDO("mysql:host=localhost;dbname=coworker_freeorder","coworker_free","freeorder2017");
?>